package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    CheckBox cb1;
    CheckBox cb2;
    CheckBox cb3;
    CheckBox cb4;
    CheckBox cb5;
    Button btn1;
    TextView txt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        cb1 = findViewById((R.id.cb1));
        cb2 = findViewById((R.id.cb2));
        cb3 = findViewById((R.id.cb3));
        cb4 = findViewById((R.id.cb4));
        cb5 = findViewById((R.id.cb5));
        btn1 = findViewById((R.id.btn1));
        txt1 = findViewById((R.id.txt1));
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1,v2,v3,v4,v5,resultado;
                v1=0.00;
                v2=0.00;
                v3=0.00;
                v4=0.00;
                v5=0.00;
                if (cb1.isChecked()){
                    v1=2.69;
                }
                if (cb2.isChecked()){
                    v2=5.00;
                }
                if (cb3.isChecked()){
                    v3=10.00;
                }
                if (cb4.isChecked()){
                    v4=2.30;
                }
                if (cb5.isChecked()){
                    v5=2.00;
                }
                resultado=v1+v2+v3+v4+v5;
                txt1.setText("O total deu: R$"+resultado);
            }
        });
    }
}